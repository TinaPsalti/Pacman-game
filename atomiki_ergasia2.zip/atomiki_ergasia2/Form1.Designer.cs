﻿namespace atomiki_ergasia2
{
    partial class GameForm
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            start_button = new Button();
            label1 = new Label();
            easyrb = new RadioButton();
            mediumrb = new RadioButton();
            hardrb = new RadioButton();
            pacmanPB = new PictureBox();
            groupBox1 = new GroupBox();
            game_timer = new System.Windows.Forms.Timer(components);
            cherry_timer = new System.Windows.Forms.Timer(components);
            label2 = new Label();
            label3 = new Label();
            scoreL = new Label();
            timeL = new Label();
            cherryPB = new PictureBox();
            lifetimeTimer = new System.Windows.Forms.Timer(components);
            pacmanClosedPB = new PictureBox();
            openTimer = new System.Windows.Forms.Timer(components);
            ((System.ComponentModel.ISupportInitialize)pacmanPB).BeginInit();
            groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)cherryPB).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pacmanClosedPB).BeginInit();
            SuspendLayout();
            // 
            // start_button
            // 
            start_button.BackColor = Color.Gold;
            start_button.Font = new Font("Arial", 18F, FontStyle.Regular, GraphicsUnit.Point, 0);
            start_button.ForeColor = SystemColors.ControlText;
            start_button.Location = new Point(150, 311);
            start_button.Name = "start_button";
            start_button.Size = new Size(227, 84);
            start_button.TabIndex = 0;
            start_button.Text = "Start Game";
            start_button.UseVisualStyleBackColor = false;
            start_button.Click += start_button_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Arial", 13.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label1.ForeColor = SystemColors.ButtonHighlight;
            label1.Location = new Point(150, 38);
            label1.Name = "label1";
            label1.Size = new Size(190, 26);
            label1.TabIndex = 1;
            label1.Text = "Choose Difficulty:";
            // 
            // easyrb
            // 
            easyrb.AutoSize = true;
            easyrb.Checked = true;
            easyrb.Font = new Font("Arial", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            easyrb.ForeColor = SystemColors.ButtonHighlight;
            easyrb.Location = new Point(34, 37);
            easyrb.Name = "easyrb";
            easyrb.Size = new Size(75, 27);
            easyrb.TabIndex = 2;
            easyrb.TabStop = true;
            easyrb.Text = "Easy";
            easyrb.UseVisualStyleBackColor = true;
            // 
            // mediumrb
            // 
            mediumrb.AutoSize = true;
            mediumrb.Font = new Font("Arial", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            mediumrb.ForeColor = SystemColors.ButtonHighlight;
            mediumrb.Location = new Point(34, 89);
            mediumrb.Name = "mediumrb";
            mediumrb.Size = new Size(100, 27);
            mediumrb.TabIndex = 3;
            mediumrb.Text = "Medium";
            mediumrb.UseVisualStyleBackColor = true;
            // 
            // hardrb
            // 
            hardrb.AutoSize = true;
            hardrb.Font = new Font("Arial", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            hardrb.ForeColor = SystemColors.ButtonHighlight;
            hardrb.Location = new Point(34, 147);
            hardrb.Name = "hardrb";
            hardrb.Size = new Size(73, 27);
            hardrb.TabIndex = 4;
            hardrb.Text = "Hard";
            hardrb.UseVisualStyleBackColor = true;
            // 
            // pacmanPB
            // 
            pacmanPB.Image = Properties.Resources.pacmanImage1;
            pacmanPB.Location = new Point(412, 180);
            pacmanPB.Name = "pacmanPB";
            pacmanPB.Size = new Size(68, 71);
            pacmanPB.SizeMode = PictureBoxSizeMode.StretchImage;
            pacmanPB.TabIndex = 5;
            pacmanPB.TabStop = false;
            pacmanPB.Visible = false;
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(easyrb);
            groupBox1.Controls.Add(mediumrb);
            groupBox1.Controls.Add(hardrb);
            groupBox1.Location = new Point(150, 77);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(227, 208);
            groupBox1.TabIndex = 6;
            groupBox1.TabStop = false;
            groupBox1.Text = "9";
            // 
            // game_timer
            // 
            game_timer.Tick += game_timer_Tick;
            // 
            // cherry_timer
            // 
            cherry_timer.Tick += cherry_timer_Tick;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Arial", 13.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label2.ForeColor = SystemColors.ButtonHighlight;
            label2.Location = new Point(25, 18);
            label2.Name = "label2";
            label2.Size = new Size(173, 26);
            label2.TabIndex = 7;
            label2.Text = "Remaining time:";
            label2.Visible = false;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Arial", 13.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label3.ForeColor = SystemColors.ButtonHighlight;
            label3.Location = new Point(560, 18);
            label3.Name = "label3";
            label3.Size = new Size(79, 26);
            label3.TabIndex = 8;
            label3.Text = "Score:";
            label3.Visible = false;
            // 
            // scoreL
            // 
            scoreL.AutoSize = true;
            scoreL.Font = new Font("Arial", 13.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            scoreL.ForeColor = SystemColors.ButtonHighlight;
            scoreL.Location = new Point(645, 18);
            scoreL.Name = "scoreL";
            scoreL.Size = new Size(25, 26);
            scoreL.TabIndex = 9;
            scoreL.Text = "0";
            scoreL.Visible = false;
            // 
            // timeL
            // 
            timeL.AutoSize = true;
            timeL.Font = new Font("Arial", 13.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            timeL.ForeColor = SystemColors.ButtonHighlight;
            timeL.Location = new Point(204, 18);
            timeL.Name = "timeL";
            timeL.Size = new Size(25, 26);
            timeL.TabIndex = 10;
            timeL.Text = "0";
            timeL.Visible = false;
            // 
            // cherryPB
            // 
            cherryPB.Image = Properties.Resources.newCherryImage1;
            cherryPB.Location = new Point(726, 77);
            cherryPB.Name = "cherryPB";
            cherryPB.Size = new Size(62, 53);
            cherryPB.SizeMode = PictureBoxSizeMode.StretchImage;
            cherryPB.TabIndex = 11;
            cherryPB.TabStop = false;
            cherryPB.Visible = false;
            // 
            // lifetimeTimer
            // 
            lifetimeTimer.Tick += lifetimeTimer_Tick;
            // 
            // pacmanClosedPB
            // 
            pacmanClosedPB.Image = Properties.Resources.pacmanClosedM;
            pacmanClosedPB.Location = new Point(521, 180);
            pacmanClosedPB.Name = "pacmanClosedPB";
            pacmanClosedPB.Size = new Size(68, 71);
            pacmanClosedPB.SizeMode = PictureBoxSizeMode.StretchImage;
            pacmanClosedPB.TabIndex = 12;
            pacmanClosedPB.TabStop = false;
            // 
            // openTimer
            // 
            openTimer.Tick += openTimer_Tick;
            // 
            // GameForm
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.ActiveCaptionText;
            BackgroundImage = Properties.Resources.background_ergasia_pacman;
            ClientSize = new Size(902, 485);
            Controls.Add(pacmanClosedPB);
            Controls.Add(cherryPB);
            Controls.Add(timeL);
            Controls.Add(scoreL);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(groupBox1);
            Controls.Add(pacmanPB);
            Controls.Add(label1);
            Controls.Add(start_button);
            Name = "GameForm";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Game";
            Load += Form1_Load;
            KeyDown += GameForm_KeyDown;
            ((System.ComponentModel.ISupportInitialize)pacmanPB).EndInit();
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)cherryPB).EndInit();
            ((System.ComponentModel.ISupportInitialize)pacmanClosedPB).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button start_button;
        private Label label1;
        private RadioButton easyrb;
        private RadioButton mediumrb;
        private RadioButton hardrb;
        private PictureBox pacmanPB;
        private GroupBox groupBox1;
        private System.Windows.Forms.Timer game_timer;
        private System.Windows.Forms.Timer cherry_timer;
        private Label label2;
        private Label label3;
        private Label scoreL;
        private Label timeL;
        private PictureBox cherryPB;
        private System.Windows.Forms.Timer lifetimeTimer;
        private PictureBox pacmanClosedPB;
        private System.Windows.Forms.Timer openTimer;
    }
}
