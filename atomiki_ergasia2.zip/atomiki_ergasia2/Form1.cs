using System.Media;

namespace atomiki_ergasia2
{
    public partial class GameForm : Form
    {
        private int timeRemaining;
        private int score;
        private Random random;
        private PictureBox newPictureBox;
        private SoundPlayer player;
        private SoundPlayer fruitPlayer;
        private bool openMouth;
        public GameForm()
        {
            InitializeComponent();
            this.KeyPreview = true;
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.GameForm_KeyDown);
            random = new Random();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            Stream stream = new MemoryStream(Properties.Resources.intro);
            player = new SoundPlayer(stream);
            player.Play();

            Stream fruitStream = new MemoryStream(Properties.Resources.Fruit);
            fruitPlayer = new SoundPlayer(fruitStream);

            openMouth = true;
        }

        private void start_button_Click(object sender, EventArgs e)
        {
            this.Focus();
            this.BackgroundImage = null;
            this.BackColor = Color.Black;

            label1.Visible = false;
            easyrb.Visible = false;
            mediumrb.Visible = false;
            hardrb.Visible = false;
            start_button.Visible = false;
            pacmanPB.Visible = true;
            groupBox1.Visible = false;
            pacmanClosedPB.Visible = false;
            label2.Visible = true;
            label3.Visible = true;
            scoreL.Visible = true;
            timeL.Visible = true;

            pacmanPB.Location = new Point(400, 180);
            pacmanClosedPB.Location = pacmanPB.Location;

            string selectedValue = "Easy";
            cherry_timer.Interval = 1000;

            int cherryLifetime = 5000;

            if (mediumrb.Checked)
            {
                selectedValue = "Medium";
                cherryLifetime = 4000;
            }
            else if (hardrb.Checked)
            {
                selectedValue = "Hard";
                cherryLifetime = 3000;
            }

            lifetimeTimer.Interval = cherryLifetime;

            game_timer.Interval = 1000;
            timeRemaining = 30;
            score = 0;

            game_timer.Start();
            cherry_timer.Start();

            openTimer.Interval = 500;
            openTimer.Start();

            timeL.Text = $"{timeRemaining}";
            scoreL.Text = $"{score}";

            this.Tag = cherryLifetime;
            player.Stop();

        }

        private void game_timer_Tick(object sender, EventArgs e)
        {
            if (timeRemaining > 0)
            {
                timeRemaining--;
                timeL.Text = $"{timeRemaining}";

                foreach (Control control in this.Controls)
                {
                    if (control is PictureBox cherry && cherry.Tag?.ToString() == "cherry" &&
                        pacmanPB.Bounds.IntersectsWith(cherry.Bounds))
                    {
                        this.Controls.Remove(cherry);
                        score += 100;
                        scoreL.Text = $"{score}";
                        fruitPlayer.Play();
                        break;
                    }
                }
            }
            else
            {
                game_timer.Stop();
                cherry_timer.Stop();
                openTimer.Stop();
                MessageBox.Show($"Time's up! Your final score is {score}.");

                DialogResult result = MessageBox.Show("Would you like to play again?", "Play Again", MessageBoxButtons.YesNo);
                if (result == DialogResult.Yes)
                {
                    Application.Restart();
                }
                else
                {
                    this.Close();
                }
            }
        }

        private void GameForm_KeyDown(object sender, KeyEventArgs e)
        {
            int step = 5;
            int maxRight = this.ClientSize.Width - pacmanPB.Width;
            int maxBottom = this.ClientSize.Height - pacmanPB.Height;

            switch (e.KeyCode)
            {
                case Keys.Left:
                    pacmanPB.Left = Math.Max(0, pacmanPB.Left - step);
                    pacmanClosedPB.Left = pacmanPB.Left;
                    break;
                case Keys.Right:
                    pacmanPB.Left = Math.Min(maxRight, pacmanPB.Left + step);
                    pacmanClosedPB.Left = pacmanPB.Left;
                    break;
                case Keys.Up:
                    pacmanPB.Top = Math.Max(0, pacmanPB.Top - step);
                    pacmanClosedPB.Top = pacmanPB.Top;
                    break;
                case Keys.Down:
                    pacmanPB.Top = Math.Min(maxBottom, pacmanPB.Top + step);
                    pacmanClosedPB.Top = pacmanPB.Top;
                    break;
            }

            foreach (Control control in this.Controls)
            {
                if (control is PictureBox cherry && cherry.Tag?.ToString() == "cherry")
                {
                    if (pacmanPB.Bounds.IntersectsWith(cherry.Bounds))
                    {
                        this.Controls.Remove(cherry);
                        score += 100;
                        scoreL.Text = $"{score}";
                        fruitPlayer.Play();
                        break;
                    }
                }
            }
        }

        private void cherry_timer_Tick(object sender, EventArgs e)
        {
            PictureBox newPictureBox = new PictureBox
            {
                Width = cherryPB.Width,
                Height = cherryPB.Height,
                Image = cherryPB.Image,
                SizeMode = cherryPB.SizeMode,
                BackColor = Color.Transparent,
                Tag = "cherry"
            };

            int maxX = this.ClientSize.Width - newPictureBox.Width;
            int maxY = this.ClientSize.Height - newPictureBox.Height;
            newPictureBox.Location = new Point(random.Next(maxX), random.Next(maxY));

            this.Controls.Add(newPictureBox);
            newPictureBox.BringToFront();

            lifetimeTimer.Start();
        }

        private void lifetimeTimer_Tick(object sender, EventArgs e)
        {
            foreach (Control control in this.Controls)
            {
                if (control is PictureBox cherry && cherry.Tag?.ToString() == "cherry")
                {
                    this.Controls.Remove(cherry);
                }
            }
            lifetimeTimer.Stop();
        }

        private void openTimer_Tick(object sender, EventArgs e)
        {
            pacmanPB.Visible = openMouth;
            pacmanClosedPB.Visible = !openMouth;
            openMouth = !openMouth;
        }
    }
}
